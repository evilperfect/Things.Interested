#ifndef NJIT8021XCLIENT_H
#define NJIT8021XCLIENT_H

extern const struct GlobalConfig {
	const char *package_name;
	const char *package_version;
	const char *locale_dir;
} g_config;

#endif//NJIT8021XCLIENT_H
